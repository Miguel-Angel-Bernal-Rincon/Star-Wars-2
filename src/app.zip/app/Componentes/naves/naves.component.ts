import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-naves',
  templateUrl: './naves.component.html',
  styleUrls: ['./naves.component.scss']
})
export class NavesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
