import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-especies',
  templateUrl: './especies.component.html',
  styleUrls: ['./especies.component.scss']
})
export class EspeciesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
